from __future__ import annotations
from typing import TYPE_CHECKING
from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship
from db_core import IdMixin, TimestampMixin
from . import Base

if TYPE_CHECKING:
    from .room_speaker import RoomSpeaker 
    from .language_speaker import LanguageSpeaker
    from .user import User


class Speaker(Base, IdMixin, TimestampMixin):
    __tablename__ = "speakers"

    biography: Mapped[str] = mapped_column(String, nullable=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    user: Mapped["User"] = relationship("User", back_populates="speaker")
    
    rooms: Mapped[list["RoomSpeaker"]] = relationship(
        "RoomSpeaker",
        back_populates="speaker",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    languages: Mapped[list["LanguageSpeaker"]] = relationship(
        "LanguageSpeaker",
        back_populates="speaker",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
