from __future__ import annotations
from typing import TYPE_CHECKING
from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from db_core import IdMixin, TimestampMixin
from . import Base

if TYPE_CHECKING:
    from .speaker import Speaker
    from .room import Room

class RoomSpeaker(Base, IdMixin, TimestampMixin):
    __tablename__ = "room_speaker"
    
    room_id: Mapped[int] = mapped_column(ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False)
    speaker_id: Mapped[int] = mapped_column(ForeignKey("speakers.id", ondelete="CASCADE"), nullable=False)

    room: Mapped["Room"] = relationship("Room", back_populates="speakers")
    speaker: Mapped["Speaker"] = relationship("Speaker", back_populates="rooms")
    