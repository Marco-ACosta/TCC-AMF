from __future__ import annotations
from typing import TYPE_CHECKING
from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db_core import IdMixin, TimestampMixin
from . import Base

if TYPE_CHECKING:
    from .language_translator import LanguageTranslator

class Language(Base, IdMixin, TimestampMixin):
    __tablename__ = "languages"

    code: Mapped[str] = mapped_column(String(10), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)

    translators: Mapped[list["LanguageTranslator"]] = relationship(
        "LanguageTranslator",
        back_populates="languages",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
