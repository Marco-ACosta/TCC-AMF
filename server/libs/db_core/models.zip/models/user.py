from __future__ import annotations
from typing import TYPE_CHECKING
from sqlalchemy import String, Index, func
from db_core import IdMixin, TimestampMixin
from db_core.models import Base
from sqlalchemy.orm import Mapped, mapped_column, relationship
if TYPE_CHECKING:
    from .speaker import Speaker
    from .translator import Translator


class User(Base, IdMixin, TimestampMixin):
    __tablename__ = "users"

    name: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str] = mapped_column(String(320), nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    is_admin: Mapped[bool] = mapped_column(default=False)
    is_speaker: Mapped[bool] = mapped_column(default=False)
    is_translator: Mapped[bool] = mapped_column(default=False)

    speaker: Mapped["Speaker"] = relationship("Speaker", back_populates="user", uselist=False)
    translator: Mapped["Translator"] = relationship("Translator", back_populates="user", uselist=False)


    __table_args__ = (
        Index("uq_users_email_lower", func.lower(email), unique=True),
    )

    def set_password_hash(self, password_hash: str) -> None:
        self.password_hash = password_hash
