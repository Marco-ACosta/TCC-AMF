from __future__ import annotations
from typing import TYPE_CHECKING
from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from db_core import IdMixin, TimestampMixin
from . import Base

if TYPE_CHECKING:    
    from .language import Language
    from .speaker import Speaker

class LanguageSpeaker(Base, IdMixin, TimestampMixin):
    __tablename__ = "language_speaker"

    language_id: Mapped[int] = mapped_column(ForeignKey("languages.id", ondelete="CASCADE"), nullable=False)
    translator_id: Mapped[int] = mapped_column(ForeignKey("speakers.id", ondelete="CASCADE"), nullable=False)

    language: Mapped["Language"] = relationship("Language", back_populates="speaker")
    speaker: Mapped["Speaker"] = relationship("Translator", back_populates="language")
